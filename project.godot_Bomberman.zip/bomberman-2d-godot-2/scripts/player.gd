extends CharacterBody2D
@export var speed = 200.0

func _ready():
	print("On ready player")

func _physics_process(_delta):
	var direction = Input.get_vector("move_left", "move_right", "move_up", "move_down")
	velocity = direction * speed
	move_and_slide()

const Bomba = preload("res://scenes/bomba/rigid_body_2d.tscn")
var explosionBomba = preload("res://scenes/bomba/explosionBomba.tscn")
var explosionBloque = preload("res://assets/bloqueDestructible/cpu_particles_2d.tscn")

func _input(event):
	if event.is_action_pressed("Bomba"):
		var bomba = Bomba.instantiate()
		bomba.position = position
		get_parent().add_child(bomba)
		explode(bomba)

func explode(bomba: RigidBody2D):
	await get_tree().create_timer(2).timeout
	var explosion = explosionBomba.instantiate()
	explosion.position = bomba.position
	bomba.get_parent().add_child(explosion)
	explosion.restart()
	bomba.queue_free()

	await get_tree().create_timer(0.05).timeout

	for area in explosion.get_node("Area2D").get_overlapping_areas():
		if area.is_in_group("bloque_destructible"):
			
			var bloque = area.get_parent()
			var explosion2 = explosionBloque.instantiate()
			get_parent().add_child(explosion2)
			explosion2.global_position = bloque.global_position
			explosion2.emitting = true
			bloque.queue_free()
			destroy_explosion_after(explosion2)

	await get_tree().create_timer(1).timeout
	explosion.queue_free()

func destroy_explosion_after(explosion2: Node2D):
	await get_tree().create_timer(1).timeout
	if is_instance_valid(explosion2):
		explosion2.queue_free()

func _on_area_2d_body_exited(body: Node2D) -> void:
	if body.get_class() == "RigidBody2D":
		body.collision_layer = 1
	pass
